/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 05
*/

#ifndef ARRAY_H
# define ARRAY_H

# include "container.h"

extern const Class  *Array;

#endif

