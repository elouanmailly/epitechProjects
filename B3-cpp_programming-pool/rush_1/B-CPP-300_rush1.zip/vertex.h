/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 02
*/

#ifndef VERTEX_H
# define VERTEX_H

# include "object.h"

extern const Class  *Vertex;

#endif

