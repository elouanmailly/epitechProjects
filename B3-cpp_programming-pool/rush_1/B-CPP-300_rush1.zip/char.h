/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 04
*/

#ifndef CHAR_H
# define CHAR_H

# include "object.h"

extern const Class  *Char;

#endif

