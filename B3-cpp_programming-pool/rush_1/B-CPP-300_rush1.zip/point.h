/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 02
*/

#ifndef POINT_H
# define POINT_H

# include "object.h"

extern const Class  *Point;

#endif
