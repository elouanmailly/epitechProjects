/*
** EPITECH PROJECT, 2018
** cpp_rush1
** File description:
** Exercice 04
*/

#ifndef FLOAT_H
# define FLOAT_H

# include "object.h"

extern const Class  *Float;

#endif

